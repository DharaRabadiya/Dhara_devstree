package com.dhara.devstree

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import com.dhara.devstree.adapter.SearchAutoCompleteAdapter
import com.dhara.devstree.datamodel.Item
import com.dhara.devstree.db.AppDatabase
import com.dhara.devstree.repo.ItemRepository
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient


class MainActivity : AppCompatActivity() {
    private lateinit var map: GoogleMap
    private lateinit var placesClient: PlacesClient
    private lateinit var itemRepository: ItemRepository
    private lateinit var searchAutoComplete: AutoCompleteTextView
    private lateinit var searchResultListView: ListView
    lateinit var txtBtnSave : Button

    var current_place_id : String = ""
    var current_place_description : String = ""
     var current_lat: Double = 0.0
     var current_lng: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txtBtnSave = findViewById(R.id.txtBtnSave)
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync { googleMap ->
            map = googleMap
            setupMap()
        }
        val itemDao = AppDatabase.getDatabase(applicationContext).itemDao()
        itemRepository = ItemRepository(itemDao)
        // Initialize Places API
        Places.initialize(applicationContext, "AIzaSyBSNyp6GQnnKlrMr7hD2HGiyF365tFlK5U")

        placesClient = Places.createClient(this)

        searchAutoComplete = findViewById(R.id.searchAutoComplete)
        searchResultListView = findViewById(R.id.searchResultListView)

        setupSearchBar()
        setListener()
    }

    fun setListener(){
        txtBtnSave.setOnClickListener(View.OnClickListener {
            val newItem = Item(place_id = current_place_id, place_description = current_place_description,
                place_lat = current_lat, place_lng = current_lng )
            itemRepository.insert(newItem)
            val intent = Intent(this, ListActivity::class.java)
            // start your next activity
            startActivity(intent)        })
    }

    private fun setupMap() {
        // Set map options and other configurations here
        // For example, you can enable user location, set initial camera position, etc.
        // For simplicity, we'll keep this basic.

        // Dummy location for initial camera position
        val initialLocation = LatLng(37.7749, -122.4194)
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 12f))

        // Example marker for demonstration
        val markerLocation = LatLng(37.7739, -122.4135)
        map.addMarker(MarkerOptions().position(markerLocation).title("Marker Title"))
    }

    private fun setupSearchBar() {
        val searchAdapter = SearchAutoCompleteAdapter(this, android.R.layout.simple_list_item_1)
        searchAutoComplete.setAdapter(searchAdapter)


       /* searchAutoComplete.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val placeItem = searchAdapter.getItem(position)
            Log.e("dharaaaa","sidfjdsfsfd")
            placeItem?.let {
                searchAutoComplete.setText(it.primaryText)
                hideSearchResults()
                moveCameraToPlace(it)
            }
        }*/



        searchAutoComplete.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (s.isNullOrEmpty()) {
                    hideSearchResults()
                } else {
                    showSearchResults(s.toString())
                }
            }
        })


       /* searchAutoComplete.setOnItemClickListener(OnItemClickListener { parent, view, position, id ->
            val selectedPlace = parent.getItemAtPosition(position) as String
            Toast.makeText(this@MainActivity, "Selected place: $selectedPlace", Toast.LENGTH_SHORT)
                .show()

            searchAutoComplete.setText(selectedPlace)
            hideSearchResults()
            moveCameraToPlace(selectedPlace)
        })

        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line)

        // Set the adapter to AutoCompleteTextView

        // Set the adapter to AutoCompleteTextView
        searchAutoComplete.setAdapter(adapter)

        // Add a text watcher to handle changes in the text input

        // Add a text watcher to handle changes in the text input
        searchAutoComplete.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // Call the method to fetch predictions from the Places API
                fetchPredictions(s.toString(), adapter)
            }

            override fun afterTextChanged(s: Editable) {}
        })*/
    }


    private fun showSearchResults(query: String) {
        val request = FindAutocompletePredictionsRequest.builder()
            .setQuery(query)
            .build()

        placesClient.findAutocompletePredictions(request)
            .addOnSuccessListener { response ->
                val predictions = response.autocompletePredictions

                val resultList = mutableListOf<PlaceItem>()
                for (prediction in predictions) {
                    resultList.add(PlaceItem(prediction.getPrimaryText(null).toString(),prediction.placeId))
                }

                val searchAdapter = SearchAutoCompleteAdapter(this, android.R.layout.simple_list_item_1, resultList)
                searchResultListView.adapter = searchAdapter
                searchResultListView.visibility = View.VISIBLE


                searchResultListView.setOnItemClickListener(OnItemClickListener { parent, view, position, id ->
                    val placeItem = searchAdapter.getItem(position)
                    placeItem?.let {
                        searchAutoComplete.setText(it.primaryText)
                        hideSearchResults()
                        moveCameraToPlace(it)
                    }
                   /* Toast.makeText(this@MainActivity, "Selected item: Dhara", Toast.LENGTH_SHORT)
                        .show()*/
                })

            }
            .addOnFailureListener { exception ->
                Log.e("MapsActivity", "Error getting autocomplete predictions: ${exception.message}")
            }
    }

    private fun hideSearchResults() {
        searchResultListView.visibility = View.GONE
    }

    private fun moveCameraToPlace(placeItem: PlaceItem) {
        val initialLocation = LatLng(37.7749, -122.4194)
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 12f))

        val placeFields = listOf(Place.Field.ID,Place.Field.NAME, Place.Field.LAT_LNG)


        val request = FetchPlaceRequest.builder(placeItem.placeId,placeFields).build()

        placesClient.fetchPlace(request)
            .addOnSuccessListener { response ->
                val place = response.place
                val latLng = place.latLng

                current_place_id = placeItem.placeId
                current_place_description = placeItem.primaryText
                current_lat = latLng.latitude
                current_lng = latLng.longitude
                // Move the camera to the selected place and add a marker
                latLng?.let {
                    map.animateCamera(CameraUpdateFactory.newLatLngZoom(it, 12f))
                    map.clear()
                    map.addMarker(MarkerOptions().position(it).title(placeItem.primaryText))
                }
            }
            .addOnFailureListener { exception ->
                Log.e("MapsActivity", "Error fetching place: ${exception.message}")
            }
    }
}

data class PlaceItem(val primaryText: String, val placeId: String = "")