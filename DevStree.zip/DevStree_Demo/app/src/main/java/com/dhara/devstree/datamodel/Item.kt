package com.dhara.devstree.datamodel

import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val place_id: String,
    val place_description: String,
    val place_lat: Double,
    val place_lng: Double,
)