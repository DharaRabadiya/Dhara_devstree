package com.dhara.devstree

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dhara.devstree.R
import com.dhara.devstree.adapter.ItemAdapter
import com.dhara.devstree.datamodel.Item
import com.dhara.devstree.db.AppDatabase
import com.dhara.devstree.repo.ItemRepository

class ListActivity : AppCompatActivity() , ItemAdapter.OnItemClickListener{
    private lateinit var itemAdapter: ItemAdapter
    private lateinit var itemRepository: ItemRepository
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val itemDao = AppDatabase.getDatabase(applicationContext).itemDao()
        itemRepository = ItemRepository(itemDao)

        itemAdapter = ItemAdapter(emptyList(), this)
        recyclerView.adapter = itemAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        itemRepository.allItems.observe(this, { items ->
            itemAdapter.items = items
            itemAdapter.notifyDataSetChanged()
        })

        // Example usage: Insert an item
        //val newItem = Item(name = "New Item", description = "This is a new item.")
        //insertItem(newItem)
    }

    override fun onItemClick(item: Item) {

    }
}